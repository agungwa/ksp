<!doctype html>
<html>
    <head>
        <title></title>
    </head>
    <body>
    <div class="col-lg-12">
    <div class="ibox float-e-margins">
        <div class="ibox-title">
            <h2 style="margin-top:0px">Karyawanijasah Read</h2>
            <div class="ibox-tools">
            </div>
        </div>
        <div class="ibox-content">
        
        <table class="table">
	    <tr><td>Kar Kode</td><td><?php echo $kar_kode; ?></td></tr>
	    <tr><td>Kij Sd</td><td><?php echo $kij_sd; ?></td></tr>
	    <tr><td>Kij Smp</td><td><?php echo $kij_smp; ?></td></tr>
	    <tr><td>Kij Sma</td><td><?php echo $kij_sma; ?></td></tr>
	    <tr><td>Kij D3</td><td><?php echo $kij_d3; ?></td></tr>
	    <tr><td>Kij S1</td><td><?php echo $kij_s1; ?></td></tr>
	    <tr><td>Kij S2</td><td><?php echo $kij_s2; ?></td></tr>
	    <tr><td>Kij S3</td><td><?php echo $kij_s3; ?></td></tr>
	    <tr><td>Kij Lainlain</td><td><?php echo $kij_lainlain; ?></td></tr>
	    <tr><td>Kij Status</td><td><?php echo $kij_status; ?></td></tr>
	    <tr><td>Kij Tgl</td><td><?php echo $kij_tgl; ?></td></tr>
	    <tr><td>Kij Flag</td><td><?php echo $kij_flag; ?></td></tr>
	    <tr><td>Kij Info</td><td><?php echo $kij_info; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('karyawanijasah') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
            </div>
        </div>
    </div>
    </div>
    </body>
</html>