<style>
table#01 {
  border-collapse: collapse;
  width: 100%;
  text-align: center;
}

 </style>
        <div>
            <div style="-aw-headerfooter-type:header-primary">
        <table id="01" style="width:538.7pt; border-collapse:collapse" cellspacing="0" cellpadding="0">
            <tbody>
                <tr style="height:105.85pt">
                
                <td style="width:90.5pt; border-bottom-style:solid; border-bottom-width:4.5pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                <img src="<?= base_url().'assets/images/image1.png'?>" alt="" style="margin-right:9pt; margin-left:9pt; -aw-left-pos:2.35pt; -aw-rel-hpos:margin; -aw-rel-vpos:margin; -aw-top-pos:0pt; -aw-wrap-type:square; float:left" width="111" height="103">
            </p></td>

            <td style="width:426.6pt; border-bottom-style:solid; border-bottom-width:4.5pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
            
            <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:16pt">
            <span style="font-family:Cambria; font-weight:bold">KOPERASI SIMPAN PINJAM</span></p>

            <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:14pt">
            <span style="font-family:Cambria; font-weight:bold">SIDO MUKTI MAKMUR</span></p>

            <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:8pt">
            <span style="font-family:Cambria; font-weight:bold">
            Badan Hukum : NO.268/BH/XlV.27/X/2011
            </span></p>
            
            <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:8pt">
            <span style="font-family:Cambria">
            Jln. Raya Kedu-Jumo Km 6,5 (Sroyo-Bojonegoro) Kedu Temanggung 56252
            </span></p>

            <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:8pt">
            <span style="font-family:Cambria">
            Kantor Pusat Telp (0293) 5922264 / KC Kranggan : (0293) 4962224 HP : 085867911558
            </span></p>

            <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:8pt">
            <span style="font-family:Cambria">Email :</span><span style="font-family:Cambria">&nbsp; </span>

            <a href="mailto:kspsidomuktimakmurtemanggung@gmail.com" style="text-decoration:none">
            <span style="font-family:Cambria; text-decoration:underline; color:#0563c1">kspsidomuktimakmurtemanggung@gmail.com</span>
        </a></p></td></tr></tbody>
    </table>