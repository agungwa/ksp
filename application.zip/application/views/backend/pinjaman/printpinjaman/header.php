<style>
table#01 {
  border-collapse: collapse;
  width: 100%;
  text-align: center;
}

 </style>
 
    <div>
        <div style="-aw-headerfooter-type:header-primary">
        <table id="01" cellspacing="0" cellpadding="0"  style="border-collapse:collapse">
        <tr>
            <td style="width:88.2pt; border-bottom-style:solid; border-bottom-width:4.5pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:middle">
            <p style="margin-top:0pt; margin-bottom:0pt; font-size:11pt">
            <img src=<?= base_url().'assets/images/image1.png'?> width="121" height="113" alt=""/>
            </p>
            </td>
            <td style="width:357.7pt; border-bottom-style:solid; border-bottom-width:4.5pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
           
            <span style="font-family:Calibri; font-weight:bold; color:#2e74b5">&#xa0;</span></p>
           
            <span style="font-family:Calibri; font-weight:bold; color:#2e74b5">&#xa0;</span></p>
           
            <span style="font-family:Calibri; font-weight:bold; color:#2e74b5">KOPERASI SIMPAN PINJAM</span></p>
           
            <span style="font-family:Calibri; font-weight:bold; color:#2e74b5">SIDO MUKTI MAKMUR</span></p>
           
            <span style="font-family:Calibri; font-weight:bold; color:#2e74b5">BadanHukum</span>
            <span style="font-family:Calibri; font-weight:bold; color:#2e74b5"> :</span>
            <span style="font-family:Calibri; font-weight:bold; color:#2e74b5"> NO.268/BH/XlV.27/X/2011</span></p>
           
            <span style="font-family:Calibri; font-weight:bold; color:#2e74b5">Jln</span >
            <span style="font-family:Calibri; font-weight:bold; color:#2e74b5">. Raya </span>
            <span style="font-family:Calibri; font-weight:bold; color:#2e74b5">Kedu-Jumo</span>
            <span style="font-family:Calibri; font-weight:bold; color:#2e74b5"> Km 6,5 (</span>
            <span style="font-family:Calibri; font-weight:bold; color:#2e74b5">Sroyo-Bojonegoro</span>
            <span style="font-family:Calibri; font-weight:bold; color:#2e74b5">) </span>
            <span style="font-family:Calibri; font-weight:bold; color:#2e74b5">KeduTemanggung</span>
            <span style="font-family:Calibri; font-weight:bold; color:#2e74b5"> 56252</span></p>
           
            <span style="font-family:Calibri; font-weight:bold; color:#2e74b5">Tlp</span>
            <span style="font-family:Calibri; font-weight:bold; color:#2e74b5">. 085100592941/085726594941</span></p>
           
            <span style="font-family:Calibri">&#xa0;</span></p></td></tr></table>
            
            <p style="margin-top:0pt; margin-bottom:0pt; font-size:11pt"><span style="font-family:Calibri">&#xa0;</span></p></div>
            