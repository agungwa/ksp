<html>


<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="Content-Style-Type" content="text/css" />
    <meta name="generator" content="Aspose.Words for .NET 17.1.0.0" />
    <title></title>
</head>

<body>
    <div>
        <div style="-aw-headerfooter-type:header-primary">
            <p style="margin-top:0pt; margin-left:63.8pt; margin-bottom:0pt; text-align:center; line-height:14pt"><img
                    src="/assets/img/file.png" width="121" height="113" alt=""
                    style="margin-right:9pt; margin-left:9pt; -aw-left-pos:0pt; -aw-rel-hpos:margin; -aw-rel-vpos:margin; -aw-top-pos:-98.95pt; -aw-wrap-type:square; float:left" /><span
                    style="font-family:Cambria; font-size:14pt; font-weight:bold; color:#0070c0">KOPERASI SIMPAN
                    PINJAM</span></p>
            <p style="margin-top:0pt; margin-left:72pt; margin-bottom:0pt; text-align:center; line-height:18pt"><span
                    style="font-family:Cambria; font-size:18pt; font-weight:bold; color:#0070c0">SIDO MUKTI
                    MAKMUR</span></p>
            <p style="margin-top:0pt; margin-left:72pt; margin-bottom:0pt; text-align:center; line-height:12pt"><span
                    style="font-family:Cambria; font-size:11pt; font-weight:bold; color:#0070c0">BadanHukum</span><span
                    style="font-family:Cambria; font-size:11pt; font-weight:bold; color:#0070c0"> :</span><span
                    style="font-family:Cambria; font-size:11pt; font-weight:bold; color:#0070c0">
                    NO.268/BH/XlV.27/X/2011</span></p>
            <p style="margin-top:0pt; margin-left:72pt; margin-bottom:0pt; text-align:center; font-size:11pt"><span
                    style="font-family:Cambria; color:#0070c0">Jln</span><span
                    style="font-family:Cambria; color:#0070c0">. Raya </span><span
                    style="font-family:Cambria; color:#0070c0">Kedu-Jumo</span><span
                    style="font-family:Cambria; color:#0070c0"> Km 6</span><span
                    style="font-family:Cambria; color:#0070c0">,5</span><span
                    style="font-family:Cambria; color:#0070c0"> (</span><span
                    style="font-family:Cambria; color:#0070c0">Sroyo-Bojonegoro</span><span
                    style="font-family:Cambria; color:#0070c0">) </span><span
                    style="font-family:Cambria; color:#0070c0">KeduTemanggung</span><span
                    style="font-family:Cambria; color:#0070c0"> 56252</span></p>
            <p style="margin-top:0pt; margin-left:72pt; margin-bottom:0pt; text-align:center; font-size:11pt"><span
                    style="font-family:Cambria; color:#0070c0">Tlp</span><span
                    style="font-family:Cambria; color:#0070c0">. 085100592941/085726594941</span></p>
            <p
                style="margin-top:0pt; margin-bottom:0pt; text-align:center; border-bottom:4.5pt solid #000000; padding-bottom:1pt; font-size:11pt">
                <span style="font-family:Cambria; color:#0070c0">&#xa0;</span></p>
        </div>
        <p style="margin-top:0pt; margin-bottom:10pt; line-height:115%; font-size:11pt"><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="font-family:'Times New Roman'; color:#17365d">SURAT PERMOHONAN PINJAMAN</span></p>
        <p style="margin-top:0pt; margin-bottom:10pt; line-height:115%; font-size:11pt"><span
                style="font-family:'Times New Roman'; color:#17365d">&#xa0;</span></p>
        <p style="margin-top:0pt; margin-bottom:6pt; line-height:115%; font-size:11pt"><span
                style="font-family:'Times New Roman'; color:#17365d">Yang bertanda tangan dibawah ini :</span></p>
        <p style="margin-top:0pt; margin-bottom:6pt; line-height:115%; font-size:11pt"><span
                style="font-family:'Times New Roman'; color:#17365d">Nama</span><span
                style="width:94.24pt; display:inline-block; -aw-tabstop-align:left; -aw-tabstop-pos:120.5pt">&#xa0;</span><span
                style="font-family:'Times New Roman'; color:#17365d">:</span><span
                style="font-family:'Times New Roman'; color:#17365d">……………………………………………………………………….</span></p>
        <p style="margin-top:0pt; margin-bottom:6pt; line-height:115%; font-size:12pt"><span
                style="font-family:'Times New Roman'; font-size:11pt; color:#17365d">Tempat, Tanggal Lahir</span><span
                style="width:18.79pt; display:inline-block; -aw-tabstop-align:left; -aw-tabstop-pos:120.5pt">&#xa0;</span><span
                style="font-family:'Times New Roman'; font-size:11pt; color:#17365d">:</span><span
                style="font-family:'Times New Roman'; color:#17365d"> </span><span
                style="font-family:'Times New Roman'; font-size:11pt; color:#17365d">………………………………………………………………………….</span>
        </p>
        <p style="margin-top:0pt; margin-bottom:6pt; line-height:115%; font-size:11pt"><span
                style="font-family:'Times New Roman'; color:#17365d">Alamat</span><span
                style="width:88.12pt; display:inline-block; -aw-tabstop-align:left; -aw-tabstop-pos:120.5pt">&#xa0;</span><span
                style="font-family:'Times New Roman'; color:#17365d">: ………………………………………………………………………….</span></p>
        <p style="margin-top:0pt; margin-bottom:6pt; line-height:115%; font-size:11pt"><span
                style="width:120.5pt; display:inline-block; -aw-tabstop-align:left; -aw-tabstop-pos:120.5pt">&#xa0;</span><span
                style="font-family:'Times New Roman'; color:#17365d"> …………………………………………………………………………..</span></p>
        <p style="margin-top:0pt; margin-bottom:6pt; line-height:115%; font-size:11pt"><span
                style="font-family:'Times New Roman'; color:#17365d">Pekerjaan</span><span
                style="width:70.03pt; display:inline-block; -aw-tabstop-align:left; -aw-tabstop-pos:113.4pt">&#xa0;</span><span
                style="font-family:'Times New Roman'; color:#17365d">   : ………………………………………………………………………….</span><span
                style="width:1.24pt; display:inline-block; -aw-tabstop-align:left; -aw-tabstop-pos:439.45pt">&#xa0;</span>
        </p>
        <p style="margin-top:0pt; margin-bottom:6pt; line-height:115%; font-size:11pt"><span
                style="font-family:'Times New Roman'; color:#17365d">Jenis Usaha</span><span
                style="width:19.76pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="font-family:'Times New Roman'; color:#17365d">     : ………………………………………………………………………….</span></p>
        <p style="margin-top:0pt; margin-bottom:6pt; line-height:115%; font-size:11pt"><span
                style="font-family:'Times New Roman'; color:#17365d">No HP/Tlp</span><span
                style="width:23.41pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="font-family:'Times New Roman'; color:#17365d">    : ………………………………………………………………………….</span></p>
        <p style="margin-top:0pt; margin-bottom:6pt; line-height:115%; font-size:11pt"><span
                style="font-family:'Times New Roman'; color:#17365d">Mengajukan permohonan pinjaman dengan keterangan
                sebagai berikut</span><span style="font-family:'Times New Roman'; color:#17365d"> :</span></p>
        <p style="margin-top:0pt; margin-bottom:6pt; line-height:115%; font-size:11pt"><span
                style="font-family:'Times New Roman'; color:#17365d">Pengajuan Pinjaman </span><span
                style="font-family:'Times New Roman'; color:#17365d">         </span><span
                style="font-family:'Times New Roman'; color:#17365d">: Rp</span><span
                style="font-family:'Times New Roman'; color:#17365d">………………………………………………………………………..</span></p>
        <p style="margin-top:0pt; margin-bottom:6pt; line-height:115%; font-size:11pt"><span
                style="font-family:'Times New Roman'; color:#17365d">Tenor</span><span
                style="width:9.74pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="font-family:'Times New Roman'; color:#17365d">    : …………………………………………………………………………...</span></p>
        <p style="margin-top:0pt; margin-bottom:6pt; line-height:115%; font-size:11pt"><span
                style="font-family:'Times New Roman'; color:#17365d">Barang yang Dijaminkan</span><span
                style="font-family:'Times New Roman'; color:#17365d"> </span></p>
        <p style="margin-top:0pt; margin-bottom:6pt; line-height:115%; font-size:11pt"><span
                style="font-family:'Times New Roman'; color:#17365d">Jenis merek/type</span><span
                style="width:46.27pt; display:inline-block; -aw-tabstop-align:left; -aw-tabstop-pos:120.5pt">&#xa0;</span><span
                style="font-family:'Times New Roman'; color:#17365d">: ………………………………………………………………………….</span></p>
        <p style="margin-top:0pt; margin-bottom:6pt; line-height:115%; font-size:11pt"><span
                style="font-family:'Times New Roman'; color:#17365d">Tahun Pembuatan</span><span
                style="width:40.77pt; display:inline-block; -aw-tabstop-align:left; -aw-tabstop-pos:120.5pt">&#xa0;</span><span
                style="font-family:'Times New Roman'; color:#17365d">: ………………………………………………………………………….</span></p>
        <p style="margin-top:0pt; margin-bottom:6pt; line-height:115%; font-size:11pt"><span
                style="font-family:'Times New Roman'; color:#17365d">Nomor</span><span
                style="width:89.34pt; display:inline-block; -aw-tabstop-align:left; -aw-tabstop-pos:120.5pt">&#xa0;</span><span
                style="font-family:'Times New Roman'; color:#17365d">:  …………………………………………………………………………</span></p>
        <p style="margin-top:0pt; margin-bottom:6pt; line-height:115%; font-size:11pt"><span
                style="font-family:'Times New Roman'; color:#17365d">Atas Nama</span><span
                style="width:22.82pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="font-family:'Times New Roman'; color:#17365d">     : …………………………………………………………………………</span></p>
        <p style="margin-top:0pt; margin-bottom:6pt; line-height:115%; font-size:11pt"><span
                style="font-family:'Times New Roman'; color:#17365d">Alamat</span><span
                style="width:3.62pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="font-family:'Times New Roman'; color:#17365d">    : ………………………………………………………………………….</span></p>
        <p style="margin-top:0pt; margin-bottom:6pt; line-height:115%; font-size:11pt"><span
                style="font-family:'Times New Roman'; color:#17365d">&#xa0;</span></p>
        <p style="margin-top:0pt; margin-bottom:6pt; line-height:115%; font-size:11pt"><span
                style="font-family:'Times New Roman'; color:#17365d">Kelengkapan Berkas</span><span
                style="font-family:'Times New Roman'; color:#17365d">*</span></p>
        <ol type="1" style="margin:0pt; padding-left:0pt">
            <li
                style="margin-left:49.25pt; line-height:115%; padding-left:4.75pt; font-family:'Times New Roman'; font-size:11pt; color:#17365d">
                <span>FC. KTP suami</span><span style="width:3.24pt; display:inline-block">&#xa0;</span><span
                    style="width:36pt; display:inline-block">&#xa0;</span><span
                    style="width:36pt; display:inline-block">&#xa0;</span><span
                    style="width:36pt; display:inline-block">&#xa0;</span><span>8. Surat Keterangan Dari Desa</span>
            </li>
            <li
                style="margin-left:49.25pt; line-height:115%; padding-left:4.75pt; font-family:'Times New Roman'; font-size:11pt; color:#17365d">
                <span>FC. KTP Istri/Penjamin</span><span style="width:3.19pt; display:inline-block">&#xa0;</span><span
                    style="width:36pt; display:inline-block">&#xa0;</span><span
                    style="width:36pt; display:inline-block">&#xa0;</span><span>9. Rekening Listrik</span></li>
            <li
                style="margin-left:49.25pt; line-height:115%; padding-left:4.75pt; font-family:'Times New Roman'; font-size:11pt; color:#17365d">
                <span>FC. KK</span><span style="width:1.16pt; display:inline-block">&#xa0;</span><span
                    style="width:36pt; display:inline-block">&#xa0;</span><span
                    style="width:36pt; display:inline-block">&#xa0;</span><span
                    style="width:36pt; display:inline-block">&#xa0;</span><span
                    style="width:36pt; display:inline-block">&#xa0;</span><span>10. Nomor Polisi Masih Berlaku</span>
            </li>
            <li
                style="margin-left:49.25pt; line-height:115%; padding-left:4.75pt; font-family:'Times New Roman'; font-size:11pt; color:#17365d">
                <span>FC. Surat Nikah</span><span style="width:0.19pt; display:inline-block">&#xa0;</span><span
                    style="width:36pt; display:inline-block">&#xa0;</span><span
                    style="width:36pt; display:inline-block">&#xa0;</span><span
                    style="width:36pt; display:inline-block">&#xa0;</span><span>11. Surat Keterangan Usaha</span></li>
            <li
                style="margin-left:49.25pt; line-height:115%; padding-left:4.75pt; font-family:'Times New Roman'; font-size:11pt; color:#17365d">
                <span>FC. BPKB</span><span style="width:24.31pt; display:inline-block">&#xa0;</span><span
                    style="width:36pt; display:inline-block">&#xa0;</span><span
                    style="width:36pt; display:inline-block">&#xa0;</span><span
                    style="width:36pt; display:inline-block">&#xa0;</span><span
                    style="width:36pt; display:inline-block">&#xa0;</span><span>12. PBB/SPT Tahunan</span></li>
            <li
                style="margin-left:49.25pt; line-height:115%; padding-left:4.75pt; font-family:'Times New Roman'; font-size:11pt; color:#17365d">
                <span>FC.STNK</span><span style="width:27.07pt; display:inline-block">&#xa0;</span><span
                    style="width:36pt; display:inline-block">&#xa0;</span><span
                    style="width:36pt; display:inline-block">&#xa0;</span><span
                    style="width:36pt; display:inline-block">&#xa0;</span><span
                    style="width:36pt; display:inline-block">&#xa0;</span><span>13. Anggota (Sudah Membayar Simpanan
                </span></li>
            <li
                style="margin-left:49.25pt; margin-bottom:6pt; line-height:115%; padding-left:4.75pt; font-family:'Times New Roman'; font-size:11pt; color:#17365d">
                <span>FC. SERTIFIKAT</span><span style="width:26.1pt; display:inline-block">&#xa0;</span><span
                    style="width:36pt; display:inline-block">&#xa0;</span><span
                    style="width:36pt; display:inline-block">&#xa0;</span><span
                    style="width:36pt; display:inline-block">&#xa0;</span><span>       pokok dan Wajib).</span></li>
        </ol>
        <p style="margin-top:0pt; margin-bottom:6pt; line-height:115%; font-size:11pt"><span
                style="font-family:'Times New Roman'; color:#17365d">&#xa0;</span></p>
        <p style="margin-top:0pt; margin-bottom:6pt; line-height:115%; font-size:11pt"><span
                style="font-family:'Times New Roman'; color:#17365d">Demikian Permohonan Pinjaman ini kami
                sampaikan,</span><span style="font-family:'Times New Roman'; color:#17365d"> agar dapat di
                setujui.</span></p>
        <p style="margin-top:0pt; margin-bottom:6pt; line-height:115%; font-size:11pt"><span
                style="font-family:'Times New Roman'; color:#17365d">&#xa0;</span></p>
        <p style="margin-top:0pt; margin-bottom:6pt; line-height:115%; font-size:11pt"><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="font-family:'Times New Roman'; color:#17365d">Temanggung, .........................</span></p>
        <p style="margin-top:0pt; margin-bottom:6pt; line-height:115%; font-size:11pt"><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="font-family:'Times New Roman'; color:#17365d">Pemohon</span></p>
        <p style="margin-top:0pt; margin-bottom:6pt; line-height:115%; font-size:11pt"><span
                style="font-family:'Times New Roman'; color:#17365d">&#xa0;</span></p>
        <p style="margin-top:0pt; margin-bottom:6pt; line-height:115%; font-size:11pt"><span
                style="font-family:'Times New Roman'; color:#17365d">&#xa0;</span></p>
        <p style="margin-top:0pt; margin-bottom:6pt; line-height:115%; font-size:11pt"><span
                style="font-family:'Times New Roman'; color:#17365d">&#xa0;</span></p>
        <p style="margin-top:0pt; margin-bottom:6pt; line-height:115%; font-size:11pt"><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="width:36pt; display:inline-block">&#xa0;</span><span
                style="font-family:'Times New Roman'; color:#17365d"> (…</span><span
                style="font-family:'Times New Roman'; color:#17365d">..............</span><span
                style="font-family:'Times New Roman'; color:#17365d">..</span><span
                style="font-family:'Times New Roman'; color:#17365d">....................)</span></p>
        <p style="margin-top:0pt; margin-bottom:10pt; line-height:115%; font-size:11pt"><span
                style="font-family:'Times New Roman'; color:#17365d">&#xa0;</span></p>
        <p style="margin-top:0pt; margin-bottom:10pt; line-height:115%; font-size:11pt"><span
                style="font-family:'Times New Roman'; color:#17365d">&#xa0;</span></p>
        <p style="margin-top:0pt; margin-bottom:10pt; line-height:115%; font-size:11pt"><span
                style="font-family:'Times New Roman'; color:#17365d">&#xa0;</span></p>
        <div style="-aw-headerfooter-type:footer-primary">
            <p style="margin-top:0pt; margin-bottom:0pt; font-size:11pt"><span style="font-family:Calibri">&#xa0;</span>
            </p>
        </div>
    </div>
</body>

</html>