<!doctype html>
<html>
    <head>
        <title></title>
    </head>
    <body>
    <div class="col-lg-12">
    <div class="ibox float-e-margins">
        <div class="ibox-title">
            <h2 style="margin-top:0px">Phu simkesan Read</h2>
            <div class="ibox-tools">
            </div>
        </div>
        <div class="ibox-content">
        
        <table class="table">
	    <tr><td>Phus Insentif</td><td><?php echo $phus_insentif; ?></td></tr>
	    <tr><td>Phus Gaji</td><td><?php echo $phus_gaji; ?></td></tr>
	    <tr><td>Phus Promosi</td><td><?php echo $phus_promosi; ?></td></tr>
	    <tr><td>Phus Lainlain</td><td><?php echo $phus_lainlain; ?></td></tr>
	    <tr><td>Phus Tgl</td><td><?php echo $phus_tgl; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('phusimkesan') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
            </div>
        </div>
    </div>
    </div>
    </body>
</html>