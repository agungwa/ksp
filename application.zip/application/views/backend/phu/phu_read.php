<!doctype html>
<html>
    <head>
        <title></title>
    </head>
    <body>
    <div class="col-lg-12">
    <div class="ibox float-e-margins">
        <div class="ibox-title">
            <h2 style="margin-top:0px">Phu Read</h2>
            <div class="ibox-tools">
            </div>
        </div>
        <div class="ibox-content">
        
        <table class="table">
	    <tr><td>Phu Jasapin</td><td><?php echo $phu_jasapin; ?></td></tr>
	    <tr><td>Phu Administrasipin</td><td><?php echo $phu_administrasipin; ?></td></tr>
	    <tr><td>Phu Pinaltipin</td><td><?php echo $phu_pinaltipin; ?></td></tr>
	    <tr><td>Phu Administrasisimpanan</td><td><?php echo $phu_administrasisimpanan; ?></td></tr>
	    <tr><td>Phu Phbuku</td><td><?php echo $phu_phbuku; ?></td></tr>
	    <tr><td>Phu Gaji</td><td><?php echo $phu_gaji; ?></td></tr>
	    <tr><td>Phu Operasional</td><td><?php echo $phu_operasional; ?></td></tr>
	    <tr><td>Phu Bungaivb</td><td><?php echo $phu_bungaivb; ?></td></tr>
	    <tr><td>Phu Bungasim</td><td><?php echo $phu_bungasim; ?></td></tr>
	    <tr><td>Phu Lps</td><td><?php echo $phu_lps; ?></td></tr>
	    <tr><td>Phu Komunikasi</td><td><?php echo $phu_komunikasi; ?></td></tr>
	    <tr><td>Phu Perlengkapan</td><td><?php echo $phu_perlengkapan; ?></td></tr>
	    <tr><td>Phu Penyusutan</td><td><?php echo $phu_penyusutan; ?></td></tr>
	    <tr><td>Phu Asuransi</td><td><?php echo $phu_asuransi; ?></td></tr>
	    <tr><td>Phu Insentif</td><td><?php echo $phu_insentif; ?></td></tr>
	    <tr><td>Phu Pajakkendaraan</td><td><?php echo $phu_pajakkendaraan; ?></td></tr>
	    <tr><td>Phu Rapat</td><td><?php echo $phu_rapat; ?></td></tr>
	    <tr><td>Phu Atk</td><td><?php echo $phu_atk; ?></td></tr>
	    <tr><td>Phu Keamanan</td><td><?php echo $phu_keamanan; ?></td></tr>
	    <tr><td>Phu Phpinjaman</td><td><?php echo $phu_phpinjaman; ?></td></tr>
	    <tr><td>Phu Sosial</td><td><?php echo $phu_sosial; ?></td></tr>
	    <tr><td>Phu Tayakuran</td><td><?php echo $phu_tayakuran; ?></td></tr>
	    <tr><td>Phu Koran</td><td><?php echo $phu_koran; ?></td></tr>
	    <tr><td>Phu Pajakkoprasi</td><td><?php echo $phu_pajakkoprasi; ?></td></tr>
	    <tr><td>Phu Servicekendaraan</td><td><?php echo $phu_servicekendaraan; ?></td></tr>
	    <tr><td>Phu Konsumsi</td><td><?php echo $phu_konsumsi; ?></td></tr>
	    <tr><td>Phu Rat</td><td><?php echo $phu_rat; ?></td></tr>
	    <tr><td>Phu Thr</td><td><?php echo $phu_thr; ?></td></tr>
	    <tr><td>Phu Nonoprasional</td><td><?php echo $phu_nonoprasional; ?></td></tr>
	    <tr><td>Phu Perawatankantor</td><td><?php echo $phu_perawatankantor; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('phu') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
            </div>
        </div>
    </div>
    </div>
    </body>
</html>