<!doctype html>
<html>
    <head>
        <title></title>
    </head>
    <body>
    <div class="col-lg-12">
    <div class="ibox float-e-margins">
        <div class="ibox-title">
            <h2 style="margin-top:0px">Neracaaktivatetap/h2>
            <div class="ibox-tools">
            </div>
        </div>
        <div class="ibox-content">
        
        <table class="table">
	    <tr><td>Tanah</td><td><?php echo $nat_tanah; ?></td></tr>
	    <tr><td>Bangunan</td><td><?php echo $nat_bangunan; ?></td></tr>
	    <tr><td>Elektronik</td><td><?php echo $nat_elektronik; ?></td></tr>
	    <tr><td>Kendaraan</td><td><?php echo $nat_kendaraan; ?></td></tr>
	    <tr><td>Peralatan</td><td><?php echo $nat_peralatan; ?></td></tr>
	    <tr><td>Akumulasipenyusutan</td><td><?php echo $nat_akumulasipenyusutan; ?></td></tr>
	    <tr><td>Tanggal</td><td><?php echo $nat_tanggal; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('neracaaktivatetap') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
            </div>
        </div>
    </div>
    </div>
    </body>
</html>