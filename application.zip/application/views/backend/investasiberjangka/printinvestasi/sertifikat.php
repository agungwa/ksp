<html>
<style>
table#01 {
    border-collapse: collapse;
    width: 100%;
    text-align: center;
}
table#02 {
    text-align: justify;
}
table#03 {
    text-align: center;
}
table#04 {
    text-align: right;
}
</style>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="Content-Style-Type" content="text/css">
    <meta name="generator" content="Aspose.Words for .NET 17.1.0.0">
    <title></title>
</head>

<body  id="example2">
    <div>
        <table id="01" style="border-collapse:collapse" cellspacing="0" cellpadding="0">
            <tbody>
                <tr style="height:517.25pt">
                    <td style="width:704.8pt; border-style:solid; border-width:4.5pt; padding-right:3.15pt; padding-left:3.15pt; vertical-align:top; background-color:#ffffff">
                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:11pt"><span
                                style="height:0pt; display:block; position:absolute; z-index:-1"></span><span style="font-family:Calibri">&nbsp;</span></p>
                        <table style="border-collapse:collapse" cellspacing="0" cellpadding="0">
                            <tbody>
                                <tr>
                                    <td
                                        style="width:693.5pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:11pt"><span
                                                style="font-family:Calibri">&nbsp;</span></p>
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:11pt"><span
                                                style="font-family:Calibri">&nbsp;</span></p>
                                    </td>
                                </tr>
                                <tr>
                                    <td
                                        style="width:693.5pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:6pt; margin-bottom:0pt; text-align:center; font-size:28pt">
                                            <span
                                                style="font-family:'Old English Text MT'; font-weight:bold">Sertifikat</span><span
                                                style="font-family:'Old English Text MT'; font-weight:bold">
                                            </span><span
                                                style="font-family:'Old English Text MT'; font-weight:bold">Investasi</span><span
                                                style="font-family:'Old English Text MT'; font-weight:bold">
                                            </span><span
                                                style="font-family:'Old English Text MT'; font-weight:bold">Berjangka</span><span
                                                style="font-family:'Old English Text MT'; font-weight:bold"> </span></p>
                                    </td>
                                </tr>
                                <tr>
                                    <td
                                        style="width:693.5pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p
                                            style="margin-top:0pt; margin-bottom:0pt; text-align:center; line-height:80%; font-size:16pt">
                                            <span style="font-family:Calibri; font-weight:bold">Nomor</span><span
                                                style="font-family:Calibri; font-weight:bold"> :</span><span
                                                style="font-family:Calibri; font-weight:bold">&nbsp;<?php echo $ivb_kode ?>/SPSB.SMM/<?php
                                                $array_bln = array(1=>"I","II","III", "IV", "V","VI","VII","VIII","IX","X", "XI","XII");
                                                $bln = $array_bln[date('n')];
                                                echo $bln;
                                                ?>/<?php echo date('Y'); ?></span></p>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:11pt"><span
                                style="font-family:Calibri">&nbsp;</span></p>
                        <table id="02" style="border-collapse:collapse" cellspacing="0" cellpadding="0">
                            <tbody>
                                <tr>
                                    <td
                                        style="width:106.55pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">Atas</span><span
                                                style="font-family:Calibri"> </span><span
                                                style="font-family:Calibri">nama</span></p>
                                    </td>
                                    <td
                                        style="width:7.15pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">:</span></p>
                                    </td>
                                    <td colspan="4"
                                        style="width:558.2pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">&nbsp;<?php echo $nama_ang_no ?></span></p>
                                    </td>
                                </tr>
                                <tr>
                                    <td
                                        style="width:200.55pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">Nomor</span><span
                                                style="font-family:Calibri"> </span><span
                                                style="font-family:Calibri">Anggota</span></p>
                                    </td>
                                    <td
                                        style="width:7.15pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">:</span></p>
                                    </td>
                                    <td colspan="4"
                                        style="width:558.2pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">&nbsp;<?php echo $ang_no ?></span></p>
                                    </td>
                                </tr>
                                <tr>
                                    <td
                                        style="width:106.55pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">Alamat</span></p>
                                    </td>
                                    <td
                                        style="width:7.15pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">:</span></p>
                                    </td>
                                    <td colspan="4"
                                        style="width:558.2pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">&nbsp;<?php echo $alamat_ang_no ?></span></p>
                                    </td>
                                </tr>
                                <tr>
                                    <td
                                        style="width:106.55pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">Sejumlah</span></p>
                                    </td>
                                    <td
                                        style="width:7.15pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">:</span></p>
                                    </td>
                                    <td colspan="4"
                                        style="width:558.2pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">&nbsp;<?php echo rupiahsimpanan($ivb_jumlah); ?></span></p>
                                    </td>
                                </tr>
                                <tr>
                                    <td
                                        style="width:106.55pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">Terbilang</span></p>
                                    </td>
                                    <td
                                        style="width:7.15pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">:</span></p>
                                    </td>
                                    <td colspan="4"
                                        style="width:558.2pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">&nbsp;<?php echo terbilang($ivb_jumlah),' Rupiah'; ?></span></p>
                                    </td>
                                </tr>
                                <tr>
                                    <td
                                        style="width:106.55pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">Jasa</span></p>
                                    </td>
                                    <td
                                        style="width:7.15pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">:</span></p>
                                    </td>
                                    <td colspan="4"
                                        style="width:558.2pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">&nbsp;<?php echo $biv_id, " %"; ?></span></p>
                                    </td>
                                </tr>
                                <tr>
                                    <td
                                        style="width:106.55pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">Tanggal</span><span
                                                style="font-family:Calibri"> </span><span
                                                style="font-family:Calibri">mulai</span></p>
                                    </td>
                                    <td
                                        style="width:7.15pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">:</span></p>
                                    </td>
                                    <td
                                        style="width:206pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">&nbsp;<?php echo dateFormataja($ivb_tglpendaftaran); ?></span></p>
                                    </td>
                                    <td
                                        style="width:148.05pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">Jangka</span><span
                                                style="font-family:Calibri"> Waktu</span></p>
                                    </td>
                                    <td
                                        style="width:10.45pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">:</span></p>
                                    </td>
                                    <td
                                        style="width:161.3pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">&nbsp;<?php echo $jwi_id, " Bulan"; ?></span></p>
                                    </td>
                                </tr>
                                <tr>
                                    <td
                                        style="width:106.55pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">Jatuh</span><span
                                                style="font-family:Calibri"> tempo</span></p>
                                    </td>
                                    <td
                                        style="width:7.15pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">:</span></p>
                                    </td>
                                    <td
                                        style="width:206pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">&nbsp;<?php echo dateFormataja($jatuhtempo); ?></span></p>
                                    </td>
                                    <td
                                        style="width:148.05pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">Perpanjangan</span><span
                                                style="font-family:Calibri"> Waktu</span></p>
                                    </td>
                                    <td
                                        style="width:10.45pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">: </span></p>
                                    </td>
                                    <td
                                        style="width:161.3pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">Otomatis</span></p>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:11pt"><span
                                style="font-family:Calibri">&nbsp;</span></p>
                        <table style="border-collapse:collapse" cellspacing="0" cellpadding="0">
                            <tbody>
                                <tr>
                                    <td
                                        style="width:341.35pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:16pt">
                                            <span style="font-family:Calibri">&nbsp;</span></p>
                                    </td>
                                    <td
                                        style="width:341.35pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:16pt">
                                            <span style="font-family:Calibri">Temanggung</span><span
                                                style="font-family:Calibri">, </span><span
                                                style="font-family:Calibri"><?php echo hari_ini(),' , ',dateFormataja($this->tgl) ?></span></p>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:11pt"><span
                                style="font-family:Calibri">&nbsp;</span></p>
                        <table style="border-collapse:collapse" cellspacing="0" cellpadding="0">
                            <tbody>
                                <tr>
                                    <td
                                        style="width:341.35pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:16pt">
                                            <span style="font-family:Calibri">Anggota</span><span
                                                style="font-family:Calibri"> / Investor</span><span
                                                style="font-family:Calibri">,</span></p>
                                    </td>
                                    <td
                                        style="width:341.35pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:16pt">
                                            <span style="font-family:Calibri">Penerima</span><span
                                                style="font-family:Calibri"> / </span><span
                                                style="font-family:Calibri">Pimpinan</span><span
                                                style="font-family:Calibri"> KSP,</span></p>
                                    </td>
                                </tr>
                                <tr>
                                    <td
                                        style="width:341.35pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">&nbsp;</span></p>
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">&nbsp;</span></p>
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">&nbsp;</span></p>
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">&nbsp;</span></p>
                                    </td>
                                    <td
                                        style="width:341.35pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">&nbsp;</span></p>
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">&nbsp;</span></p>
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">&nbsp;</span></p>
                                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                                style="font-family:Calibri">&nbsp;</span></p>
                                    </td>
                                </tr>
                                <tr>
                                    <td
                                        style="width:341.35pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:16pt">
                                            <span style="font-family:Calibri">(<?php echo $nama_ang_no; ?>)</span></p>
                                    </td>
                                    <td
                                        style="width:341.35pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
                                        <p style="margin-top:0pt; margin-bottom:0pt; text-align:center; font-size:16pt">
                                            <span style="font-family:Calibri">(ARIYADI, A.md)</span></p>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                style="font-family:Calibri">&nbsp;</span></p>
                        <table style="border-collapse:collapse" cellspacing="0" cellpadding="0">
                            <tbody>
                                <tr>
                                    <td
                                        style="width:693.5pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top; background-color:#00b0f0">
                                        <p
                                            style="margin-top:0pt; margin-left:21.3pt; margin-bottom:0pt; text-indent:-14.2pt; font-size:16pt">
                                            <span style="font-family:Wingdings; color:#ffffff">>></span><span
                                                style="font:7pt 'Times New Roman'"> </span><span
                                                style="font-family:Calibri; font-weight:bold; color:#ffffff">Sertifikat</span><span
                                                style="font-family:Calibri; font-weight:bold; color:#ffffff">
                                            </span><span
                                                style="font-family:Calibri; font-weight:bold; color:#ffffff">ini</span><span
                                                style="font-family:Calibri; font-weight:bold; color:#ffffff">
                                            </span><span
                                                style="font-family:Calibri; font-weight:bold; color:#ffffff">merupakan</span><span
                                                style="font-family:Calibri; font-weight:bold; color:#ffffff">
                                            </span><span
                                                style="font-family:Calibri; font-weight:bold; color:#ffffff">Bukti</span><span
                                                style="font-family:Calibri; font-weight:bold; color:#ffffff">
                                            </span><span
                                                style="font-family:Calibri; font-weight:bold; color:#ffffff">Simpanan</span><span
                                                style="font-family:Calibri; font-weight:bold; color:#ffffff">
                                            </span><span
                                                style="font-family:Calibri; font-weight:bold; color:#ffffff">uang</span><span
                                                style="font-family:Calibri; font-weight:bold; color:#ffffff"> yang
                                            </span><span
                                                style="font-family:Calibri; font-weight:bold; color:#ffffff">diinvestasikan</span><span
                                                style="font-family:Calibri; font-weight:bold; color:#ffffff"> pada KSP
                                            </span><span
                                                style="font-family:Calibri; font-weight:bold; color:#ffffff">Sido</span><span
                                                style="font-family:Calibri; font-weight:bold; color:#ffffff"> Mukti
                                                Makmur.</span></p>
                                        <p
                                            style="margin-top:0pt; margin-left:21.3pt; margin-bottom:0pt; text-indent:-14.2pt; font-size:16pt">
                                            <span
                                                style="font-family:Wingdings; font-size:12pt; color:#ffffff">>></span><span
                                                style="font:7pt 'Times New Roman'">&nbsp;&nbsp; </span><span
                                                style="font-family:Calibri; font-weight:bold; color:#ffffff">Ketentuan</span><span
                                                style="font-family:Calibri; font-weight:bold; color:#ffffff"> lain
                                            </span><span
                                                style="font-family:Calibri; font-weight:bold; color:#ffffff">sesuai</span><span
                                                style="font-family:Calibri; font-weight:bold; color:#ffffff">
                                            </span><span
                                                style="font-family:Calibri; font-weight:bold; color:#ffffff">dengan</span><span
                                                style="font-family:Calibri; font-weight:bold; color:#ffffff"> Surat
                                            </span><span
                                                style="font-family:Calibri; font-weight:bold; color:#ffffff">Perjanjian</span><span
                                                style="font-family:Calibri; font-weight:bold; color:#ffffff">
                                            </span><span
                                                style="font-family:Calibri; font-weight:bold; color:#ffffff">Investasi</span><span
                                                style="font-family:Calibri; font-weight:bold; color:#ffffff">
                                            </span><span
                                                style="font-family:Calibri; font-weight:bold; color:#ffffff">Berjangka</span><span
                                                style="font-family:Calibri; font-weight:bold; color:#ffffff">.</span>
                                        </p>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                style="font-family:Calibri">&nbsp;</span></p>
                        <p style="margin-top:0pt; margin-bottom:0pt; font-size:16pt"><span
                                style="font-family:Calibri">&nbsp;</span></p>
                    </td>
                </tr>
            </tbody>
        </table>
        <p style="margin-top:0pt; margin-bottom:8pt; line-height:108%; font-size:11pt"><span
                style="font-family:Calibri">&nbsp;</span></p>
    </div>
</body>

</html>